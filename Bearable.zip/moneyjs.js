function showfood(){
  document.getElementById("food").style.display = "block";
}

function showtransport(){
  document.getElementById("transport").style.display = "block";
}

function showperson(){
  document.getElementById("person").style.display = "block";
}

function submit(){
  var income = parseInt(document.getElementById("incomei").value);
  var food = parseInt(document.getElementById("foodi").value);
  var transportation = parseInt(document.getElementById("transportation").value);
  var personal = parseInt(document.getElementById("personal").value);

  var spent=(((food+transportation+personal)/income)*100)
  var jarpercent= 100-spent

}
